#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
#include <string.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <stdbool.h>

/*
This version will fire up the same number of processes as cores.
The array data is shared.
The mutex to keep count and the count itself are also shared.
 */

#define SIZE    2

struct block {
    int size;
    int *first;
};

struct num_cores {
    int num_cores_remaining;
    pthread_mutex_t num_cores_mutex;
};

struct num_cores *num_cores_shared;

/*
 * Returns the number of active cores in this machine.
 */
int get_num_cores() {
    long num = sysconf(_SC_NPROCESSORS_ONLN);
    if (num == -1) {
        perror("ERROR getting number of cores");
    }
    return (int)num;
}

void merge(struct block *left, struct block *right) {
	int combined[left->size + right->size]; // this is where the space is allocated
	int dest = 0, l = 0, r = 0;
	while (l < left->size && r < right->size) {
		if (left->first[l] < right->first[r])
			combined[dest++] = left->first[l++];
		else
			combined[dest++] = right->first[r++];
	}
	while (l < left->size)
		combined[dest++] = left->first[l++];
	while (r < right->size)
		combined[dest++] = right->first[r++];
    memmove(left->first, combined, (left->size + right->size) * sizeof(int));
}

void *merge_sort(void *arg) {
    struct block *my_data = (struct block *)arg;
    if (my_data->size > 1) {
        struct block left_block;
        struct block right_block;
        left_block.size = my_data->size / 2;
        left_block.first = my_data->first;
        right_block.size = left_block.size + (my_data->size % 2);
        right_block.first = my_data->first + left_block.size;
        if (pthread_mutex_lock(&num_cores_shared->num_cores_mutex) != 0) {
            perror("mutex lock merge_sort");
            exit(EXIT_FAILURE);
        }
        if (num_cores_shared->num_cores_remaining > 0) {
            num_cores_shared->num_cores_remaining--;
            if (pthread_mutex_unlock(&num_cores_shared->num_cores_mutex) != 0) {
                perror("mutex unlock merge_sort");
                exit(EXIT_FAILURE);
            }
            pid_t left_proc = fork();
            if (left_proc == 0) {
                // printf("child\n");
                merge_sort(&left_block);
                exit(EXIT_SUCCESS);
            } else {
                // printf("parent\n");
                merge_sort(&right_block);
                waitpid(left_proc, NULL, 0);
                if (pthread_mutex_lock(&num_cores_shared->num_cores_mutex) != 0) {
                    perror("mutex lock merge_sort");
                    exit(EXIT_FAILURE);
                }
                num_cores_shared->num_cores_remaining++;
                if (pthread_mutex_unlock(&num_cores_shared->num_cores_mutex) != 0) {
                    perror("mutex unlock merge_sort");
                    exit(EXIT_FAILURE);
                }
            }
        } else {
            if (pthread_mutex_unlock(&num_cores_shared->num_cores_mutex) != 0) {
                perror("mutex unlock merge_sort");
                exit(EXIT_FAILURE);
            }
            merge_sort(&left_block);
            merge_sort(&right_block);
        }
        merge(&left_block, &right_block);
    }
}

/* Check to see if the data is sorted. */
bool is_sorted(int data[], int size) {
    bool sorted = true;
    for (int i = 0; i < size - 1; i++) {
        if (data[i] > data[i + 1])
            sorted = false;
    }
    return sorted;
}

int main(int argc, char *argv[]) {
	long size;

	if (argc < 2) {
		size = SIZE;
	} else {
		size = atol(argv[1]);
	}
    struct rlimit stack_size;
    getrlimit(RLIMIT_STACK, &stack_size);
    // printf("stack limit: %ld\n", stack_size.rlim_cur);
    if (size * 5 > 16384) {
        stack_size.rlim_cur = 5 * size; // stack only needs to be half the size of data
        setrlimit(RLIMIT_STACK, &stack_size);
        getrlimit(RLIMIT_STACK, &stack_size);
        // printf("stack limit: %ld\n", stack_size.rlim_cur);
    }

    printf("starting:\n");
    struct block start_block;
    // int data[size]; // here is the data
    int *data;
    data = (int *)mmap(NULL, sizeof(int) * size, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (data == (int *)-1) {
        perror("unable to allocate shared data");
        exit(EXIT_FAILURE);
    }
    num_cores_shared = (struct num_cores *)mmap(NULL, sizeof(struct num_cores), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

    pthread_mutexattr_t attr;
    if (pthread_mutexattr_init(&attr) != 0) {
        perror("mutex attr");
        exit(EXIT_FAILURE);
    }
    if (pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED) != 0) {
        perror("mutex attr shared");
        exit(EXIT_FAILURE);
    }
    if (pthread_mutex_init(&num_cores_shared->num_cores_mutex, &attr) != 0) {
        perror("mutex init");
        exit(EXIT_FAILURE);
    }
    if (pthread_mutex_lock(&num_cores_shared->num_cores_mutex) != 0) {
        perror("mutex lock main");
        exit(EXIT_FAILURE);
    }
    num_cores_shared->num_cores_remaining = get_num_cores() - 1;
    // printf("num cores remaining: %d", num_cores_shared->num_cores_remaining);
    if (pthread_mutex_unlock(&num_cores_shared->num_cores_mutex) != 0) {
        perror("mutex unlock main");
        exit(EXIT_FAILURE);
    }

    start_block.size = size;
    start_block.first = data;
    for (int i = 0; i < size; i++) {
        data[i] = rand();
    }
    merge_sort(&start_block);
    printf(":ending.\n");
    printf(is_sorted(data, size) ? "sorted\n" : "not sorted\n");
    munmap(data, sizeof(int) * size);
    munmap(num_cores_shared, sizeof(struct num_cores));
    exit(EXIT_SUCCESS);
}