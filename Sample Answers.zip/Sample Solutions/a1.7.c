#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
#include <string.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/types.h>
// #include <sys/mman.h>
#include <stdbool.h>
#include <sys/file.h>

/*
This version will fire up the number of processes corresponding to the number of cores.
The array data is returned via a pipe.
In this one the data is sent in one large chunk.
The current number of cores is communicated via a pipe.
This pipe is shared between all processes.
A lock is implicit on this pipe because reading threads block until the remaining
number of cores gets written back to the pipe.
 */

#define SIZE    2

struct block {
    int size;
    int *first;
};

int num_cores_pipe[2];   // the pipe containing the number of cores remaining

/*
 * Returns the number of active cores in this machine.
 */
int get_num_cores() {
    long num = sysconf(_SC_NPROCESSORS_ONLN);
    if (num == -1) {
        perror("ERROR getting number of cores");
        exit(EXIT_FAILURE);
    }
    return (int)num;
}

void merge(struct block *left, struct block *right) {
	int combined[left->size + right->size]; // this is where the space is allocated
	int dest = 0, l = 0, r = 0;
	while (l < left->size && r < right->size) {
		if (left->first[l] < right->first[r])
			combined[dest++] = left->first[l++];
		else
			combined[dest++] = right->first[r++];
	}
	while (l < left->size)
		combined[dest++] = left->first[l++];
	while (r < right->size)
		combined[dest++] = right->first[r++];
    memmove(left->first, combined, (left->size + right->size) * sizeof(int));
}

int get_remaining_cores() { // sets the lock and keeps it
    int num_cores_remaining;
    if (read(num_cores_pipe[0], &num_cores_remaining, sizeof(int)) < 0) {
        perror("reading cores");
        exit(EXIT_FAILURE);
    }
    // printf("cores remaining: %d\n", num_cores_remaining);
    return num_cores_remaining;
}

void set_remaining_cores(int num_cores_remaining) { // assume file locked
    // printf("setting num cores: %d\n", num_cores_remaining);
    if (write(num_cores_pipe[1], &num_cores_remaining, sizeof(int)) < 0) {
        perror("writing cores");
        exit(EXIT_FAILURE);
    }
}

void merge_sort(void *arg) {
    struct block *my_data = (struct block *)arg;
    if (my_data->size > 1) {
        struct block left_block;
        struct block right_block;
        left_block.size = my_data->size / 2;
        left_block.first = my_data->first;
        right_block.size = left_block.size + (my_data->size % 2);
        right_block.first = my_data->first + left_block.size;

        int remaining_cores = get_remaining_cores();
        if (remaining_cores > 0) {
            int my_pipe[2];
            set_remaining_cores(remaining_cores - 1);
            if (pipe(my_pipe) == -1) {
                perror("creating pipe");
                exit(EXIT_FAILURE);
            }
            pid_t left_proc = fork();
            if (left_proc == -1) {
                perror("calling fork");
                exit(EXIT_FAILURE);               
            }
            if (left_proc == 0) {
                close(my_pipe[0]);
                merge_sort(&left_block);
                // transmit the sorted data back
                int result;
                result = write(my_pipe[1], left_block.first, sizeof(int) * left_block.size);
                if (result == -1) {
                    perror("writing data");
                    exit(EXIT_FAILURE);
                }
                if (result != sizeof(int) * left_block.size) {
                    printf("data size when writing is wrong\n");
                    exit(EXIT_FAILURE);
                }

                remaining_cores = get_remaining_cores();
                if (remaining_cores < 0 || remaining_cores > 3) {
                    printf("AAArgh!!!\n");
                }
                set_remaining_cores(remaining_cores + 1);

                exit(EXIT_SUCCESS);
            } else {
                close(my_pipe[1]);
                merge_sort(&right_block);
                // retrieve the sorted data 
                int result;
                result = read(my_pipe[0], left_block.first, sizeof(int) * left_block.size);
                if (result == -1) {
                    perror("reading data");
                    exit(EXIT_FAILURE);
                }
                if (result != sizeof(int) * left_block.size) {
                    printf("data size when reading is wrong\n");
                    exit(EXIT_FAILURE);
                }
            }
        } else {
            set_remaining_cores(remaining_cores);
            merge_sort(&left_block);
            merge_sort(&right_block);
        }
        merge(&left_block, &right_block);
    }
}

/* Check to see if the data is sorted. */
bool is_sorted(int data[], int size) {
    bool sorted = true;
    for (int i = 0; i < size - 1; i++) {
        if (data[i] > data[i + 1])
            sorted = false;
    }
    return sorted;
}


int main(int argc, char *argv[]) {
	long size;
    int num_cores_remaining;

	if (argc < 2) {
		size = SIZE;
	} else {
		size = atol(argv[1]);
	}
    struct rlimit stack_size;
    getrlimit(RLIMIT_STACK, &stack_size);
    if (size * 9 > 16384) {
        stack_size.rlim_cur = 9 * size;
        setrlimit(RLIMIT_STACK, &stack_size);
        getrlimit(RLIMIT_STACK, &stack_size);
    }
    num_cores_remaining = get_num_cores() - 1;

    if (pipe(num_cores_pipe) == -1) {
        perror("opening num cores pipe");
        exit(EXIT_FAILURE);
    }
    if (write(num_cores_pipe[1], &num_cores_remaining, sizeof(int)) < 0) {
        perror("writing cores main");
        exit(EXIT_FAILURE);
    }
    printf("starting---\n");
    int data[size]; // here is the data
    struct block start_block;
    start_block.size = size;
    start_block.first = data;
    for (int i = 0; i < size; i++) {
        data[i] = rand();
    }
    merge_sort(&start_block);
    printf("---ending.\n");
    printf(is_sorted(data, size) ? "sorted\n" : "not sorted\n");
    exit(EXIT_SUCCESS);
}