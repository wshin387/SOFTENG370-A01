q#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
#include <string.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <stdbool.h>

/*
This version will fire up two processes to do the work.
The array data is shared.
 */

#define SIZE    2

struct block {
    int size;
    int *first;
    int level;
};


void merge(struct block *left, struct block *right) {
	int combined[left->size + right->size]; // this is where the space is allocated
	int dest = 0, l = 0, r = 0;
	while (l < left->size && r < right->size) {
		if (left->first[l] < right->first[r])
			combined[dest++] = left->first[l++];
		else
			combined[dest++] = right->first[r++];
	}
	while (l < left->size)
		combined[dest++] = left->first[l++];
	while (r < right->size)
		combined[dest++] = right->first[r++];
    memmove(left->first, combined, (left->size + right->size) * sizeof(int));
}

void *merge_sort(void *arg) {
    struct block *my_data = (struct block *)arg;
    if (my_data->size > 1) {
        struct block left_block;
        struct block right_block;
        left_block.size = my_data->size / 2;
        left_block.first = my_data->first;
        left_block.level = my_data->level + 1;
        right_block.size = left_block.size + (my_data->size % 2);
        right_block.first = my_data->first + left_block.size;
        right_block.level = my_data->level + 1;
        if (my_data->level < 1) {
            pid_t left_proc = fork();
            if (left_proc == 0) {
                // printf("child\n");
                merge_sort(&left_block);
                exit(EXIT_SUCCESS);
            } else {
                // printf("parent\n");
                merge_sort(&right_block);
                waitpid(left_proc, NULL, 0);
            }
        } else {
            merge_sort(&left_block);
            merge_sort(&right_block);
        }
        merge(&left_block, &right_block);
    }
}

/* Check to see if the data is sorted. */
bool is_sorted(int data[], int size) {
    bool sorted = true;
    for (int i = 0; i < size - 1; i++) {
        if (data[i] > data[i + 1])
            sorted = false;
    }
    return sorted;
}

int main(int argc, char *argv[]) {
	long size;

	if (argc < 2) {
		size = SIZE;
	} else {
		size = atol(argv[1]);
	}
    struct rlimit stack_size;
    getrlimit(RLIMIT_STACK, &stack_size);
    // printf("stack limit: %ld\n", stack_size.rlim_cur);
    if (size * 5 > 16384) {
        stack_size.rlim_cur = 5 * size; // stack only needs to be half the size of data
        setrlimit(RLIMIT_STACK, &stack_size);
        getrlimit(RLIMIT_STACK, &stack_size);
        // printf("stack limit: %ld\n", stack_size.rlim_cur);
    }

    printf("starting:\n");
    struct block start_block;
    // int data[size]; // here is the data
    int *data;
    data = (int *)mmap(NULL, sizeof(int) * size, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (data == (int *)-1) {
        perror("unable to allocate shared data");
        exit(EXIT_FAILURE);
    }
    start_block.size = size;
    start_block.first = data;
    start_block.level = 0;
    for (int i = 0; i < size; i++) {
        data[i] = rand();
    }
    merge_sort(&start_block);
    printf(":ending.\n");
    printf(is_sorted(data, size) ? "sorted\n" : "not sorted\n");
    munmap(data, sizeof(int) * size);
    exit(EXIT_SUCCESS);
}