#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
#include <string.h>
#include <sys/resource.h>

/*
    This version fires up one extra thread to take the left half.
 */

#define SIZE    2

struct block {
    int size;
    int *first;
    // int level;
};

int num_cores_remaining;

void merge(struct block *left, struct block *right) {
	int combined[left->size + right->size]; // this is where the space is allocated
	int dest = 0, l = 0, r = 0;
	while (l < left->size && r < right->size) {
		if (left->first[l] < right->first[r])
			combined[dest++] = left->first[l++];
		else
			combined[dest++] = right->first[r++];
	}
	while (l < left->size)
		combined[dest++] = left->first[l++];
	while (r < right->size)
		combined[dest++] = right->first[r++];
    memmove(left->first, combined, (left->size + right->size) * sizeof(int));
}

void *merge_sort(void *arg) {
    pthread_attr_t thread_attr;
    size_t size;
    pthread_t left_thread;
    struct block *my_data = (struct block *)arg;
    if (my_data->size > 1) {
        struct block left_block;
        struct block right_block;
        left_block.size = my_data->size / 2;
        left_block.first = my_data->first;
        right_block.size = left_block.size + (my_data->size % 2);
        right_block.first = my_data->first + left_block.size;

        if (num_cores_remaining < 1) {   // no more threads
            merge_sort(&left_block);
            merge_sort(&right_block);
        } else {
            pthread_attr_init(&thread_attr);
            size = 5 * my_data->size;
            if (size < 16384)
                size = 16384;
            if (pthread_attr_setstacksize(&thread_attr, size)) {
                perror("ouch stacksize");
                exit(EXIT_FAILURE);
            }
            num_cores_remaining = 0; // ok at the moment because only one thread ever gets here
            if (pthread_create(&left_thread, &thread_attr, merge_sort, &left_block)) {
                perror("ouch create left");
                exit(EXIT_FAILURE);
            }
            merge_sort(&right_block);
            pthread_join(left_thread, NULL);
            pthread_attr_destroy(&thread_attr);
        }
        merge(&left_block, &right_block);
    }
}

int main(int argc, char *argv[]) {
	long size;

	if (argc < 2) {
		size = SIZE;
	} else {
		size = atol(argv[1]);
	}
    struct rlimit stack_size;
    getrlimit(RLIMIT_STACK, &stack_size);
    if (size * 9 > 16384) {
        stack_size.rlim_cur = 9 * size;
        setrlimit(RLIMIT_STACK, &stack_size);
        // getrlimit(RLIMIT_STACK, &stack_size);
    }

    num_cores_remaining = 1;

    printf("starting---\n");
    struct block start_block;
    int data[size];
    // int *element;
    start_block.size = size;
    start_block.first = data;
    // start_block.level = 0;
    for (int i = 0; i < size; i++) {
        data[i] = rand();
        // printf("%d\n", data[i]);
    }
    merge_sort(&start_block);
    printf("---ending.\n");
    int ordered = 1;
    for (int i = 0; i < size - 1; i++) {
        if (data[i] > data[i + 1])
            ordered = 0;
    }
    ordered == 0 ? printf("not sorted\n") : printf("sorted\n");
    exit(EXIT_SUCCESS);
}