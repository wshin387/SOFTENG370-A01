#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
#include <string.h>
#include <sys/resource.h>

/*
This version uses a spinlock to protect a counter for how many threads
are available.
 */

#define SIZE    2

struct block {
    int size;
    int *first;
};

int num_cores_remaining;
pthread_spinlock_t num_cores_spinlock;

/*
 * Returns the number of active cores in this machine.
 */
int get_num_cores() {
    long num = sysconf(_SC_NPROCESSORS_ONLN);
    if (num == -1) {
        perror("ERROR getting number of cores");
    }
    return (int)num;
}

// void print_block_data(struct block *blk) {
//     printf("size: %d address: %p\n", blk->size, blk->first);
// }

void merge(struct block *left, struct block *right) {
	int combined[left->size + right->size]; // this is where the space is allocated
	int dest = 0, l = 0, r = 0;
	while (l < left->size && r < right->size) {
		if (left->first[l] < right->first[r])
			combined[dest++] = left->first[l++];
		else
			combined[dest++] = right->first[r++];
	}
	while (l < left->size)
		combined[dest++] = left->first[l++];
	while (r < right->size)
		combined[dest++] = right->first[r++];
    memmove(left->first, combined, (left->size + right->size) * sizeof(int));
}

void *merge_sort(void *arg) {
    pthread_attr_t thread_attr;
    size_t size;
    pthread_t left_thread;
    struct block *my_data = (struct block *)arg;

    if (my_data->size > 1) {
        struct block left_block;
        struct block right_block;
        left_block.size = my_data->size / 2;
        left_block.first = my_data->first;
        right_block.size = left_block.size + (my_data->size % 2);
        right_block.first = my_data->first + left_block.size;

        pthread_spin_lock(&num_cores_spinlock);
        if (num_cores_remaining < 1) {   // no more threads
            pthread_spin_unlock(&num_cores_spinlock);

            merge_sort(&left_block);
            merge_sort(&right_block);
        } else {
            num_cores_remaining--;
            pthread_spin_unlock(&num_cores_spinlock);

            pthread_attr_init(&thread_attr);
            size = 5 * my_data->size;
            if (size < 16384)
                size = 16384;
            if (pthread_attr_setstacksize(&thread_attr, size)) {
                perror("ouch stacksize");
                exit(EXIT_FAILURE);
            }
            if (pthread_create(&left_thread, &thread_attr, merge_sort, &left_block)) {
                perror("ouch create left");
                exit(EXIT_FAILURE);
            }
            merge_sort(&right_block);
            pthread_join(left_thread, NULL);

            pthread_spin_lock(&num_cores_spinlock);
            num_cores_remaining++;
            pthread_spin_unlock(&num_cores_spinlock);

            pthread_attr_destroy(&thread_attr);
        }
        merge(&left_block, &right_block);
    }
}

int main(int argc, char *argv[]) {
	long size;

	if (argc < 2) {
		size = SIZE;
	} else {
		size = atol(argv[1]);
	}
    struct rlimit stack_size;
    getrlimit(RLIMIT_STACK, &stack_size);
    if (size * 9 > 16384) {
        stack_size.rlim_cur = 9 * size;
        setrlimit(RLIMIT_STACK, &stack_size);
        getrlimit(RLIMIT_STACK, &stack_size);
    }

    pthread_spin_init(&num_cores_spinlock, PTHREAD_PROCESS_PRIVATE);
    pthread_spin_lock(&num_cores_spinlock);
    num_cores_remaining = get_num_cores() - 1;
    pthread_spin_unlock(&num_cores_spinlock);

    printf("starting---\n");
    struct block start_block;
    int data[size];
    start_block.size = size;
    start_block.first = data;
    for (int i = 0; i < size; i++) {
        data[i] = rand();
    }
    merge_sort(&start_block);
    printf("---ending.\n");
    int ordered = 1;
    for (int i = 0; i < size - 1; i++) {
        if (data[i] > data[i + 1])
            ordered = 0;
    }
    ordered == 0 ? printf("not sorted\n") : printf("sorted\n");
    exit(EXIT_SUCCESS);
}